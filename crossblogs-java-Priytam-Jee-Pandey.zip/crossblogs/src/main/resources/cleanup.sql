TRUNCATE article;
TRUNCATE comment;